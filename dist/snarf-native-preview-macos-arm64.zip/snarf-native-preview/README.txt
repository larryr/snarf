Snarf native preview — macOS (Apple Silicon / arm64 only)
===========================================================

This is a PREVIEW build from an in-review branch (PR #24, "Phase 18: build
devdraw in-tree", ADR-0006) — not yet merged to main. It is not notarized or
signed with a Developer ID (ad-hoc/linker-signed only), so Gatekeeper will
refuse to run it the first time.

To run it:
  1. Unzip this folder somewhere, e.g. ~/Applications/snarf-native/
  2. Keep snarf-native and devdraw in the SAME folder — snarf-native finds
     devdraw by looking beside its own executable.
  3. Clear the quarantine flag that macOS stamps on downloaded files:
       xattr -dr com.apple.quarantine /path/to/snarf-native-preview
  4. Run it from a terminal:
       cd /path/to/snarf-native-preview
       ./snarf-native
     The first line printed should say:
       snarf-native: devdraw: <path>/devdraw (bundled)
     A devdraw window should then open.

Requirements: macOS on Apple Silicon (arm64). This build was not produced
for Intel Macs — it will not run there.

Built from commit 005013c on branch phase18-devdraw-build (PR #24).
